Lab 6 Solution is online.  Questions were not assigned because of Kaggle. 

[Solution R](https://www.kaggle.com/jasonkuruzovich/titanic/mgmt6963-lab6) 

[Solution Python](https://www.kaggle.com/jasonkuruzovich/titanic/mgmt6963-lab6-python)